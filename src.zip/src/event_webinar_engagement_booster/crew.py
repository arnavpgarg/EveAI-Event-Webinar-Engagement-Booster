import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task



from crewai_tools import CrewaiEnterpriseTools



@CrewBase
class EventWebinarEngagementBoosterCrew:
    """EventWebinarEngagementBooster crew"""

    
    @agent
    def event_engagement_manager(self) -> Agent:
        enterprise_actions_tool = CrewaiEnterpriseTools(
            actions_list=[
                
                "google_sheets_get_spreadsheet",
                
                "google_sheets_get_values",
                
                "google_gmail_send_email",
                
            ],
        )

        
        return Agent(
            config=self.agents_config["event_engagement_manager"],
            
            
            tools=[
				*enterprise_actions_tool
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="groq/llama-3.1-8b-instant",
                temperature=0.7,
            ),
            
        )
    

    
    @task
    def track_and_analyze_event_engagement(self) -> Task:
        return Task(
            config=self.tasks_config["track_and_analyze_event_engagement"],
            markdown=False,
            
            
        )
    
    @task
    def execute_complete_email_campaign(self) -> Task:
        return Task(
            config=self.tasks_config["execute_complete_email_campaign"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the EventWebinarEngagementBooster crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
