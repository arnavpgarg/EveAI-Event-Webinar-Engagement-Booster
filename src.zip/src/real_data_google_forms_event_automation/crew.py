import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task



from crewai_tools import CrewaiEnterpriseTools



@CrewBase
class RealDataGoogleFormsEventAutomationCrew:
    """RealDataGoogleFormsEventAutomation crew"""

    
    @agent
    def event_automation_manager(self) -> Agent:
        enterprise_actions_tool = CrewaiEnterpriseTools(
            actions_list=[
                
                "google_sheets_get_spreadsheet",
                
                "google_sheets_get_values",
                
                "google_sheets_update_values",
                
                "google_sheets_append_values",
                
                "google_gmail_send_email",
                
                "google_gmail_delete_email",
                
                "google_gmail_create_draft",
                
                "google_gmail_get_message",
                
                "google_gmail_get_attachment",
                
            ],
        )

        
        return Agent(
            config=self.agents_config["event_automation_manager"],
            
            
            tools=[
				*enterprise_actions_tool
            ],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            max_execution_time=None,
            llm=LLM(
                model="groq/gemma2-9b-it",
                temperature=0.2,
            ),
            
        )
    

    
    @task
    def setup_google_forms_integration_bridge(self) -> Task:
        return Task(
            config=self.tasks_config["setup_google_forms_integration_bridge"],
            markdown=False,
            
            
        )
    
    @task
    def extract_and_analyze_real_event_registration_data(self) -> Task:
        return Task(
            config=self.tasks_config["extract_and_analyze_real_event_registration_data"],
            markdown=False,
            
            
        )
    
    @task
    def execute_production_email_campaign_with_real_delivery(self) -> Task:
        return Task(
            config=self.tasks_config["execute_production_email_campaign_with_real_delivery"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the RealDataGoogleFormsEventAutomation crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )

    def _load_response_format(self, name):
        with open(os.path.join(self.base_directory, "config", f"{name}.json")) as f:
            json_schema = json.loads(f.read())

        return SchemaConverter.build(json_schema)
